import styled from "styled-components"

const Selector = ({selectedNum, setSelectedNum}) => {
const arrNum = [1, 2, 3, 4, 5, 6];

return (
<SelectorContainer>
<div className="flex">
{arrNum.map((value,i)  => (
    <Square 
    isSelected={value ===selectedNum}
    key={i}
    onClick={() => setSelectedNum(value)}
    >
        {value}
    </Square>
)
)
}
</div>
<p>Select Number</p>
</SelectorContainer>
)
}

export default Selector;

const SelectorContainer = styled.div`
display:flex;
flex-direction:column;
align-items:end;

.flex{
    display:flex;
    gap:24px;
}
p{
    font-size: 24px;
    font-weight: 700;
}
`

const Square = styled.div`
height: 72px;
width: 72px;
border: 1px solid black;
display: grid;
place-items: center;
font-size: 24px;
font-weight:700;
background-color: ${(props) => (props.isSelected ? "black" : "white")};
color: ${(props)=>(!props.isSelected ? "black" : "white")};
`;
