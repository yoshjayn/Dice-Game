import styled from "styled-components";
import Score from "./Score";
import Selector from "./Selector";
import DiceRoll from "./DiceRoll";
import { useState } from "react";


const GamePlay = () => {
    const [score, setScore] = useState();
const [selectedNum, setSelectedNum] = useState();
const [currentRoll, setCurrentRoll] = useState(1);

//role dice function ko v yaha lana pdega

const RandomNum = (min, max) => {
    return Math.floor(Math.random()*(max-min)+min);
    };
const rollDice=() =>{
const randomNum = RandomNum(1,7);
    
    setCurrentRoll((prev) => randomNum);
    
    if(selectedNum==randomNum){
        setScore((prev) => prev + randomNum);
    } else{
        setScore((prev) => prev - 2);
    }
    };

return (
    <Main>
        <div className="top-section">
<Score score={score}/>
<Selector selectedNum={selectedNum}
        setSelectedNum={setSelectedNum}
/>
        </div>
<DiceRoll currentRoll={currentRoll}
            rollDice={rollDice}
/>
    </Main>
);
};

export default GamePlay;

const Main = styled.main`
padding-top: 70px;
.top-section{
    display:flex;
    justify-content: space-around;
    align-items: end;
}

`;